#ifndef _MAIN_H_
#define _MAIN_H_

extern void user_init_thread_entry(void* parameter);

#endif
