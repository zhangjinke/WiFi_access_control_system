/**--------------�ļ���Ϣ--------------------------------------------------------------------------------
**
** ��   ��   ��: main.c
**
** ��   ��   ��: �Ž���
**
** �ļ���������: 2016 �� 09 �� 06 ��
**
** ��        ��: ����ϵͳ�ദ������ʼ������

** ��־:
2016.09.06  �������ļ�
*********************************************************************************************************/
#include <rtthread.h>
#include <rfid_thread.h>
#include <user_check_thread.h>

#ifdef  TOUCH_SCREEN
#include "touch_screen.h"
#endif  /* TOUCH_SCREEN */

#ifdef  TFT
#include "ILI93xx.h"
#endif  /* TFT */

#ifdef  STemWin
#include "GUI.h"
#include "WM.h"
#endif  /* STemWin */

#ifdef  RT_USING_SDIO
#include <drivers/mmcsd_core.h>
#include <drivers/sdio.h>
#include <drivers/sd.h>
#endif  /* RT_USING_SDIO */

#ifdef RT_USING_DFS
#include <dfs.h>
#include <dfs_posix.h>
#endif  /* RT_USING_DFS */

#ifdef  RT_USING_SPI
#include "spi_bus.h"
#endif  /* RT_USING_SPI */

#ifdef  EmWin_Demo
static rt_uint8_t emwin_demo_stack[ 8192 ];	//�߳�ջ
static struct rt_thread emwin_demo_thread; 	//�߳̿��ƿ�
#endif  /* EmWin_Demo */

#ifdef  TOUCH_SCREEN
static rt_uint8_t touch_screen_stack[ 2048 ];	//�߳�ջ
static struct rt_thread touch_screen_thread; 	//�߳̿��ƿ�
#endif  /* TOUCH_SCREEN */

#ifdef  RT_USING_DFS
static rt_uint8_t fs_test_stack[ 1024 ];	//�߳�ջ
static struct rt_thread fs_test_thread; 	//�߳̿��ƿ�
#endif  /* RT_USING_DFS */

#define rt_thread_delayMs(x) rt_thread_delay(rt_tick_from_millisecond(x))

/*******************************************************************************
* ������ 	: touch_screen_thread_entry
* ����   	: ������ɨ���߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
#ifdef  TOUCH_SCREEN
static void touch_screen_thread_entry(void* parameter)
{	
	while(1)
	{
		#ifdef  STemWin
		GUI_TOUCH_Exec();
		#endif  /* STemWin */
		rt_thread_delayMs(5);
	}	
}
#endif  /* TOUCH_SCREEN */

/*******************************************************************************
* ������ 	: emwin_demo_thread_entry
* ����   	: emwin_demo�߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
#ifdef  EmWin_Demo
static void emwin_demo_thread_entry(void* parameter)
{	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC,ENABLE);//����CRCʱ��
	WM_SetCreateFlags(WM_CF_MEMDEV);
	GUI_Init();  			//STemWin��ʼ��
	GUI_DispString("hello world");
	while(1)
	{
		#ifdef  EmWin_Demo
		GUIDEMO_Main();	
		#endif  /* EmWin_Demo */
		rt_thread_delayMs(5);
	}	
}
#endif  /* EmWin_Demo */

/*******************************************************************************
* ������ 	: fs_test_thread_entry
* ����   	: fs_test�߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
#ifdef  RT_USING_DFS
static void fs_test_thread_entry(void* parameter)
{
	int fd, size;
	char buffer[80];
	const char *file_name = "/CONFIG.TXT";
	
	rt_memset(buffer, 0, sizeof(buffer));
	fd = open(file_name, O_RDWR, 0);
	if (fd >= 0)
	{
		size=read(fd, buffer, sizeof(buffer));
		close(fd);
		rt_kprintf("size is %d buffer is \r\n%s\r\n", size, buffer);	
	} 
	else
	{
		rt_kprintf("open %s failed\r\n", file_name);
	}
	
	while(1)
	{
		rt_thread_delayMs(5);
	}	
}
#endif  /* RT_USING_DFS */

/*******************************************************************************
* ������ 	: user_init_thread_entry
* ����   	: �û���ʼ������
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    	: None
*******************************************************************************/
void user_init_thread_entry(void* parameter)
{
	rt_err_t result;
	
	/* ��ʼ���¼����� */
	rt_event_init(&user_check_event, "user_check_event", RT_IPC_FLAG_FIFO);	

    /* ��ʼ��SPI���� */
	rt_hw_stm32_spi_bus_init();
#ifdef  TFT
	/* ��ʼ��TFTҺ�� */
	TFTLCD_Init();
#endif  /* TFT */

#ifdef  TOUCH_SCREEN
	/* ��ʼ�������� */
	TP_Init();
#endif  /* TOUCH_SCREEN */
		
#ifdef  EmWin_Demo
    /* ��ʼ��emwin demo�߳� */
    result = rt_thread_init(&emwin_demo_thread,
                            "emwin_demo",
                            emwin_demo_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&emwin_demo_stack[0],
                            sizeof(emwin_demo_stack),
                            19,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&emwin_demo_thread);
    }
#endif  /* EmWin_Demo */
	
#ifdef  RT_USING_DFS
    /* ��ʼ��fs_test�߳� */
    result = rt_thread_init(&fs_test_thread,
                            "fs_test",
                            fs_test_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&fs_test_stack[0],
                            sizeof(fs_test_stack),
                            20,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&fs_test_thread);
    }
#endif  /* RT_USING_DFS */

#ifdef  TOUCH_SCREEN
    /* ��ʼ��touch_screen�߳� */
    result = rt_thread_init(&touch_screen_thread,
                            "touch_screen",
                            touch_screen_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&touch_screen_stack[0],
                            sizeof(touch_screen_stack),
                            18,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&touch_screen_thread);
    }
#endif  /* TOUCH_SCREEN */

#ifdef  RC522
    /* ��ʼ��rc522�߳� */
    result = rt_thread_init(&rc522_thread,
                            "rc522",
                            rc522_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&rc522_stack[0],
                            sizeof(rc522_stack),
                            21,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&rc522_thread);
    }
#endif  /* RC522 */
	
    /* ��ʼ��Ȩ�޼���߳� */
    result = rt_thread_init(&user_check_thread,
                            "user_check",
                            user_check_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&user_check_stack[0],
                            sizeof(user_check_stack),
                            19,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&user_check_thread);
    }
}
