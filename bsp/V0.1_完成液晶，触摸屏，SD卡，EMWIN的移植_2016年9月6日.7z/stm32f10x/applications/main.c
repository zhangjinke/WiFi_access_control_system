/**--------------�ļ���Ϣ--------------------------------------------------------------------------------
**
** ��   ��   ��: main.c
**
** ��   ��   ��: �Ž���
**
** �ļ���������: 2016 �� 09 �� 06 ��
**
** ��        ��: ����ϵͳ�ദ������ʼ������

** ��־:
2016.09.06  �������ļ�
*********************************************************************************************************/
#include <rtthread.h>

#include "touch_screen.h"
#include "ILI93xx.h"
#include "GUI.h"
#include "WM.h"

#ifdef  EmWin_Demo
#include "GUIDemo.h"
#endif  /* EmWin_Demo */

#ifdef  RT_USING_SDIO
#include <drivers/mmcsd_core.h>
#include <drivers/sdio.h>
#include <drivers/sd.h>
#endif  /* RT_USING_SDIO */

#ifdef RT_USING_DFS
#include <dfs.h>
#include <dfs_posix.h>
#endif  /* RT_USING_DFS */

#ifdef  RT_USING_SPI
#include "spi_bus.h"
#endif  /* RT_USING_SPI */

#ifdef  RT_USING_W25QXX
#include "spi_flash_w25qxx.h"
#endif  /* RT_USING_W25QXX */

static rt_uint8_t emwin_demo_stack[ 8192 ];
static struct rt_thread emwin_demo_thread;

static rt_uint8_t fs_test_stack[ 1024 ];
static struct rt_thread fs_test_thread;

static rt_uint8_t touch_screen_stack[ 2048 ];
static struct rt_thread touch_screen_thread;

#define rt_thread_delayMs(x) rt_thread_delay(rt_tick_from_millisecond(x))

/*******************************************************************************
* ������ 	: touch_screen_thread_entry
* ����   	: ������ɨ���߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
static void touch_screen_thread_entry(void* parameter)
{	
	while(1)
	{
		GUI_TOUCH_Exec();
		rt_thread_delayMs(5);
	}	
}

/*******************************************************************************
* ������ 	: emwin_demo_thread_entry
* ����   	: emwin_demo�߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
static void emwin_demo_thread_entry(void* parameter)
{	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC,ENABLE);//����CRCʱ��
	WM_SetCreateFlags(WM_CF_MEMDEV);
	GUI_Init();  			//STemWin��ʼ��
	GUI_DispString("hello world");
	while(1)
	{
		#ifdef  EmWin_Demo
		GUIDEMO_Main();	
		#endif  /* EmWin_Demo */
	}	
}

/*******************************************************************************
* ������ 	: fs_test_thread_entry
* ����   	: fs_test�߳�
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    : None
*******************************************************************************/
static void fs_test_thread_entry(void* parameter)
{
	int fd, size;
	char buffer[80];
	const char *file_name = "/CONFIG.TXT";
	
	rt_memset(buffer, 0, sizeof(buffer));
	fd = open(file_name, O_RDWR, 0);
	if (fd >= 0)
	{
		size=read(fd, buffer, sizeof(buffer));
		close(fd);
		rt_kprintf("size is %d buffer is \r\n%s\r\n", size, buffer);	
	} 
	else
	{
		rt_kprintf("open %s failed\r\n", file_name);
	}
	
	while(1)
	{

	}	
}

/*******************************************************************************
* ������ 	: user_init_thread_entry
* ����   	: �û���ʼ������
* ����     	: - parameter: �߳���ڲ���
* ���     	: None
* ����ֵ    	: None
*******************************************************************************/
void user_init_thread_entry(void* parameter)
{
	rt_err_t result;
	
    /* ��ʼ��SPI���� */
	rt_hw_stm32_spi_bus_init();
	
	TFTLCD_Init();
	TP_Init();
	
    /* ��ʼ��emwin demo�߳� */
    result = rt_thread_init(&emwin_demo_thread,
                            "emwin_demo",
                            emwin_demo_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&emwin_demo_stack[0],
                            sizeof(emwin_demo_stack),
                            19,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&emwin_demo_thread);
    }
	
    /* ��ʼ��fs_test�߳� */
    result = rt_thread_init(&fs_test_thread,
                            "fs_test",
                            fs_test_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&fs_test_stack[0],
                            sizeof(fs_test_stack),
                            20,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&fs_test_thread);
    }
	
    /* ��ʼ��touch_screen�߳� */
    result = rt_thread_init(&touch_screen_thread,
                            "touch_screen",
                            touch_screen_thread_entry,
                            RT_NULL,
                            (rt_uint8_t*)&touch_screen_stack[0],
                            sizeof(touch_screen_stack),
                            18,
                            5);
    if (result == RT_EOK)
    {
        rt_thread_startup(&touch_screen_thread);
    }
}
